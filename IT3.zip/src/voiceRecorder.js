var fileData;
export class VoiceRecorder {
  constructor() {
    this.mediaRecorder;
    this.stream;
    this.chunks;
    this.isRecording = false;
    this.isPaused = false;
    this.startTime;
    this.pausedTime = 0;

    this.constraints = {
      audio: true,
      video: false
    };
  }

  handleSuccess(stream) {
    this.stream = stream;
    this.stream.oninactive = () => {
      console.log("Stream ended!");
    };
    this.mediaRecorder = new MediaRecorder(this.stream);
    this.mediaRecorder.ondataavailable = this.onMediaRecorderDataAvailable.bind(this);
    this.mediaRecorder.onstop = this.onMediaRecorderStop.bind(this);
    this.mediaRecorder.onpause = this.onMediaRecorderPause.bind(this);
    this.mediaRecorder.onresume = this.onMediaRecorderResume.bind(this);
    this.startTime = Date.now();
    this.mediaRecorder.start();
	$("#recimg").hide() ; // starting the recording image animation when mediarecorder is active or mic is allowed.
	
	 setTimeout(function() {
  // using this to delay the stop button showing which forces for 5 seconds of minimum recording.
  $("#stop2").show();
  $("#stop1").hide();
}, 5000); // Delay in milliseconds

	 setTimeout(function() {
  // delaying till 60 seconds after which stop button is activated automatically hence stoping the recording.
$("#stop2").click();
}, 60000); // Delay in milliseconds

  }

  handleError(error) {
    console.log("navigator.getUserMedia error: ", error);
  }

  onMediaRecorderDataAvailable(e) {
    this.chunks.push(e.data);
  }

  onMediaRecorderStop(e) {
    var blob = new Blob(this.chunks, { type: 'audio/ogg; codecs=opus' });

    var fileReader = new FileReader();
    fileReader.onload = () => {
	 var respnumValue = $("input[name=hid_respnum]").val(); 
var cleanedrespnum = respnumValue.split(",")[0]; //initialise a variable that will hold the cleaned respondent number 

//var questionIDElement = document.querySelector('.test_label.test_question_label');
var questionID = questionlabelname; // initialising questionName/ID
       fileData = fileReader.result;
      // Upload the audio file to Dropbox when submit is clicked
	  
    var original = $('#next_button'); // cloning next button.
    var clone = $(original).clone();
    $(clone).attr('id', '');
    $(original).hide();
    $(original).after($(clone));
    $(clone).click(function(){
	if(audiodataavailable==0){
		$(clone).hide();	
		$(original).show();
		 $(original).click();
}else if(audiodataavailable == 1 && SSI_GetValue(CBoxName + "_1") == 0){
  var img = document.createElement('img');
				img.id = "loadingimg";
img.src ="[%GraphicsPath()%]loading.gif";
img.alt = 'Your Image';

// Find the next_button element
var nextButton = document.getElementById('next_button');

// Inserting the loading gif image after the next_button
nextButton.parentNode.insertBefore(img, nextButton.nextSibling);
	 $(clone).hide();
	 
	  $("#infoid").hide();
	   $(".A_RI").hide();
	   	   $(".question_errors").hide();
	    $("#error_box").hide();
	  
	 $("#"+ CBoxName +"_1_label").hide()
	 $("#"+ CBoxName +"_1_graphical").hide()
    var refreshToken = "8QRVegvIqP4AAAAAAAAAAXM8id_GjRRQai9tLSALxxxH98aTuu6DY16nBOe1mVL0";
    var base64authorization = btoa("0k4beryenn2qnob:9s01kw1dbz0xghn");
    var accessToken;
    var requestOptions = {
        method: 'POST',
        headers: {
            'Authorization': `Basic ${base64authorization}`,
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `refresh_token=${refreshToken}&grant_type=refresh_token`
    };

    fetch("https://api.dropbox.com/oauth2/token", requestOptions)
        .then(response => response.json())
        .then(data => {
            console.log('Response:', data);
            accessToken = data.access_token;

            // Upload the audio file to Dropbox
            if (fileData) {
                $("#submit1,#rerecord1").hide();
                $("#audioplay1,#audioplay2").hide();
                $("#audioplay1").hide();
                $("#loading1").removeAttr("hidden");
                $("#next_button").hide();
                $(questionlabelid).val('');
                fetch('https://content.dropboxapi.com/2/files/upload', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${accessToken}`,
                        'Content-Type': 'application/octet-stream',
                        'Dropbox-API-Arg': JSON.stringify({
                            path: '/' + 'Audio Files (First Approach)/' + questionID + '/' + cleanedrespnum + '/audio.ogg',
                            mode: 'add',
                            autorename: true,
                            mute: false
                        })
                    },
                    body: fileData
                })
                .then(response => response.json())
                .then(data => {
                    $("#loading1").removeAttr("hidden");
                    if (datasubmit == 0) {
                        datasubmit = 1;
                        var msg = 'Your voice answers are submitted.';
						$(".question").addClass("error_quest_highlight"); 
                        var div = $('<div>' + msg + '</div>');
                        div.dialog({
                            width: 500,
                            height: 'auto',
                            modal:true,
                            draggable: false,
                            resizable: false,
                            closeOnEscape: false,
                            title: "Confirm",
                            buttons: [
                                {
                                    text: "OK",
                                    click: function () {
                                        SuperVar = 1;
                                        $('.main1 div').css('transform', 'scaleY(0.423529)');
                                        $("#loading1").attr("hidden","hidden");
                                        //$("#CheckboxAudio_1_graphical").hide();
                                        //$("#CheckboxAudio_1_label").hide();
                                        $(".A_RI").html(" ");
                                       // $("#AProgressCameraTagRipped").attr("readonly","readonly");
                                       // $("#AProgressCameraTagRipped").css("background-color","#B9b9b9"); 
                                       // $("#next_button").show();
										$(".rilabel").hide();
										$(questionlabelid).val('') ;
										//$("#AudioTranscription_transcribe").val(transcript);
										$(".A_RI1").hide();
										SSI_SubmitMe();
                                        div.dialog("close");
                                    }
                                }
                            ]
                        });
                        $(".ui-widget-overlay").unbind("click");
                        $('.ui-dialog').on('keydown', function (e) {
                            if (e.keyCode == "13" || e.keyCode == "32") {
                                return false;
                            }
                        });
                    }
                    console.log('File uploaded successfully to Dropbox:', data);
                })
                .catch(error => {
                    console.log('Error uploading file to Dropbox:', error);
                });
            }
        })
        .catch(error => console.error('Error:', error));
	   
	     }
      }); // this is the submit end braces (now its the end braces of next_button clone)
	
    };

    fileReader.readAsArrayBuffer(blob);

    this.chunks = [];
    this.stream.getAudioTracks().forEach(track => track.stop());
    this.stream = null;
  }

  onMediaRecorderPause() {
    this.isPaused = true;
    this.pausedTime += Date.now() - this.startTime;
  }

  onMediaRecorderResume() {
    this.isPaused = false;
    this.startTime = Date.now() - this.pausedTime;
    this.pausedTime = 0;
  }

  startRecording() {
  
    this.chunks = [];
    if (this.isRecording && !this.isPaused) return;
    this.isRecording = true;
    this.isPaused = false;
    this.startTime = Date.now() - this.pausedTime;
    navigator.mediaDevices
      .getUserMedia(this.constraints)
      .then(this.handleSuccess.bind(this))
      .catch(this.handleError.bind(this));
  }

  pauseRecording() {
    if (!this.isRecording || this.isPaused) return;
    this.mediaRecorder.pause();
  }

  resumeRecording() {
    if (!this.isRecording || !this.isPaused) return;
    this.mediaRecorder.resume();
  }

  stopRecording() {
    if (!this.isRecording) return;
    this.mediaRecorder.stop();
  }
  
  reRecord() {
 this.chunks = [];
this.isRecording = false;

	
}
}