
//import { AudioVisualizer } from './audioVisualizer';
import { VoiceRecorder } from './voiceRecorder';

export {VoiceRecorder };

// Example usage
var voiceRecorder;

voiceRecorder = new VoiceRecorder();

document.getElementById("start1").addEventListener("click", function() {
  voiceRecorder.startRecording();
  init();
  
     $("#start1,#pause1,#stop2").hide();
   $("#start2,#stop1").show();
   $(questionlabelid).hide();
   
  $(".error_quest_highlight").removeClass("error_quest_highlight");
   $(".question_errors").hide();
   $("#error_box").hide(); 
   $(".A_RI").html("Click the <b>Stop</b> button to <b>Stop recording</b>");
   $(questionlabelid).val('') ;
   $(".rilabel").hide();
   $('#next_button').hide;
   
  
});


document.getElementById("stop2").addEventListener("click", function() {
  voiceRecorder.stopRecording();
  window.audioVisualizer.stop();
  $('.main1 div').css('transform', 'scaleY(0.423529)');
  $("#start2,#pause2,#stop2,#play1,#start1,#pause1,#stop1").hide();
  //$("#rerecord1,#submit1").show();
  $("#recimg").hide();
  //$("#audioplay1").show();
   $(".A_RI").html("Click <b>'Next'</b> to submit your audio.");
   $('#next_button').show;
   $(".A_RI1").hide();
   audiodataavailable = 1;
    SuperVar = 1;
	
	
	
		$("#CaMic_tab").hide();
	
	  $("#"+ CBoxName +"_1_graphical").hide();
	    $(".B_RI1").hide();
  $("#"+ CBoxName +"_1_label").hide();
  $("#"+ CBoxName +"_1_graphical").parent().parent().removeClass("clickable");
	//console.log(transcript); 
});




$( document ).ready(function() {
	
	function detectEdgeAndRunFunction() {
  var isEdge = window.navigator.userAgent.indexOf("Edge") > -1;
  if (isEdge) {
    // Running the specific function for Edge
    runEdgeFunction();
  } else {
    // Handle other browsers or do nothing
  }
}
$(questionlabelid).hide();
$(".rilabel").hide();
$(".A_RI1").hide();

function runEdgeFunction() {
    // empty function, will use it later for edge.
}


//let elementIDElement = document.querySelector('.test_label.test_question_label');
//let elementID ="AProgressCameraTagRipped";
//console.log(elementID);
//	var SuperVar = 0;
//	$("#AProgressCameraTagRipped_div").find(".footer").append($("#CheckboxAudio_div  >.question_body").show());
	$(QuestionDiv).find(".footer").append($( CBoxDIVAttach + " >.question_body" ).show());
    $("#start2,#pause2,#stop2,#play1,#submit1,#rerecord1").hide();
	$("#recimg").addClass("blink");
	
	
	 const elementsWithClassB_RI1 = document.querySelectorAll('.B_RI1');
  elementsWithClassB_RI1.forEach(function(element) {
    const styles = window.getComputedStyle(element, null);
    if (styles.getPropertyValue('display') === 'none') {
      
	  function func1() {
  $(".B_RI1").hide() ;
  $(".A_RI1").show() ;
  
  
}
func1();
    }
  });
	
});

function initialbutton(){
	
   $("#start1,#pause1,#stop1").show();
   $("#start2,#pause2,#stop2").hide();
}
function rerecord (){
	 $("#rerecord1,#submit1").hide();
	 $("#start1,#pause1,#stop1").show();

}


function SSI_CustomGraphicalCheckbox(GraphicalCheckboxObj, InputObj, blnCheck)
{

	
	if(InputObj.name == CBoxName + "_1" && blnCheck == true)
    {
	 voiceRecorder.chunks = [];
voiceRecorder.isRecording = false;
	audiodataavailable = 0;
	$(".rilabel").show() ;
	$(".B_RI1").hide() ;
	$(".A_RI1").hide() ;
	 SuperVar = 0;
	 


// Check if the button is hidden


	
	
	
	$(".A_RI1,#nav_buttons,#CaMic_tab,.A_RI,.A_RI2,#infoid").hide();
	$(questionlabelid).show();
	   $(".error_quest_highlight").removeClass("error_quest_highlight");
   $(".question_errors").hide();
   $("#error_box").hide();
  window.audioVisualizer.stop();  // pausing th audio visualiser upon pause button
  $('.main1 div').css('transform', 'scaleY(0.423529)'); // scaling the visualiser bar to uniform as it is paused
  $("#recimg").hide() ;
 
                
    } 
	if(InputObj.name == CBoxName + "_1" && blnCheck == false)
    { 
	
	 $(".A_RI").html("Click the <b>start</b> button to start recording.");
	
		 voiceRecorder.chunks = [];
voiceRecorder.isRecording = false;

  $('.main1 div').css('transform', 'scaleY(0.423529)'); // scaling the visualiser bar to uniform as it is paused
	 $(".error_quest_highlight").removeClass("error_quest_highlight");
   $(".question_errors").hide();
    $(".error_var_highlight1").removeClass("error_var_highlight1");
   $("#error_box").hide();
	audiodataavailable = 0;
	SuperVar = 0;
	$(".B_RI1").show() ;
	$(questionlabelid).val('') ;
	$(questionlabelid).hide();
    $(".rilabel").hide();       
	$("#start1,#stop1").show();
	$("#start2,#play1,#stop2").hide();
	

   const elementsWithClassB_RI1 = document.querySelectorAll('.B_RI1');
  elementsWithClassB_RI1.forEach(function(element) {
    const styles = window.getComputedStyle(element, null);
    if (styles.getPropertyValue('display') === 'none') {
      
	  function func1() {
  $(".B_RI1").hide() ;
  $(".A_RI1").show() ;
  
  
}
func1();
    }
  });


	/*	if (window.getComputedStyle(audioplay2).display !== 'none') {
    $("#audioplay2").hide(); //hotfix: it seems the resume button shows up if we click on checkbox after stop button
  $("#audioplay1").show();
  $("#rerecord1").show();
  $("#submit1").show();
  
  
}*/
	
	$("#nav_buttons,#CaMic_tab,.A_RI,.A_RI2,#infoid").show();
	// $("#start1,#pause1,#stop1").hide(); //fixup buttons as of 19-20-2024 comments for later implementation in php 
	/// $("#play1").show(); //fixup buttons as of 19-20-2024 comments for later implementation in php 

///var stopdButton = document.getElementById('stop2'); //fixup buttons as of 19-20-2024 comments for later implementation in php 
                
    } 
	

	
}