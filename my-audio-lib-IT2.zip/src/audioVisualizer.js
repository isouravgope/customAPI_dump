export class AudioVisualizer {
  constructor(audioContext, processFrame, processError) {
    this.audioContext = audioContext;
    this.processFrame = processFrame;
    this.connectStream = this.connectStream.bind(this);
    navigator.mediaDevices.getUserMedia({
        audio: true,
        video: false
      })
      .then(this.connectStream)
      .catch((error) => {
        if (processError) {
          processError(error);
        }
      });
  }

  connectStream(stream) {
    this.analyser = this.audioContext.createAnalyser();
    const source = this.audioContext.createMediaStreamSource(stream);
    source.connect(this.analyser);
    this.analyser.smoothingTimeConstant = 0.5;
    this.analyser.fftSize = 32;

    this.initRenderLoop(this.analyser);
  }

  initRenderLoop() {
    const frequencyData = new Uint8Array(this.analyser.frequencyBinCount);
    const processFrame = this.processFrame || (() => {});

    const renderFrame = () => {
      this.analyser.getByteFrequencyData(frequencyData);
      processFrame(frequencyData);

      this.animationFrameId = requestAnimationFrame(renderFrame);
    };
    this.animationFrameId = requestAnimationFrame(renderFrame);
  }

  stop() {
    cancelAnimationFrame(this.animationFrameId);
  }
}

const visualMainElement = document.querySelector('main');
const visualValueCount = 10;
let visualElements;
const createDOMElements = () => {
  let i;
  for (i = 0; i < visualValueCount; ++i) {
    const elm = document.createElement('div');
    visualMainElement.appendChild(elm);
  }

  visualElements = document.querySelectorAll('main div');
};
createDOMElements();

const init = () => {
  // Creating initial DOM elements
  const audioContext = new AudioContext();
  const initDOM = () => {
    visualMainElement.innerHTML = '';
    createDOMElements();
  };
  initDOM();

  // Swapping values around for a better visual effect
  const dataMap = {
    0: 15,
    1: 10,
    2: 8,
    3: 9,
    4: 6,
    5: 5,
    6: 2,
    7: 1,
    8: 0,
    9: 4,
    10: 3,
    11: 7,
    12: 11,
    13: 12,
    14: 13,
    15: 14
  };
  const processFrame = (data) => {
    const values = Object.values(data);
    let i;
    for (i = 0; i < visualValueCount; ++i) {
      const value = values[dataMap[i]] / 255;
      const elmStyles = visualElements[i].style;
      elmStyles.transform = `scaleY(${value})`;
      elmStyles.opacity = Math.max(.25, value);
    }
  };

  const processError = () => {
  //  visualMainElement.classList.add('error');
       voiceRecorder.chunks = [];
voiceRecorder.isRecording = false;
audiodataavailable = 0;
$(".rilabel").show() ;
$(".B_RI1").hide() ;
$(".A_RI1").hide() ;
SuperVar = 0;



// Check if the button is hidden





$(".A_RI1,#nav_buttons,#CaMic_tab,.A_RI,.A_RI2,#infoid").hide();
$(questionlabelid).show();
 $(".error_quest_highlight").removeClass("error_quest_highlight");
$(".question_errors").hide();
$("#error_box").hide();
window.audioVisualizer.stop();  // pausing th audio visualiser upon pause button
$('.main1 div').css('transform', 'scaleY(0.423529)'); // scaling the visualiser bar to uniform as it is paused
$("#recimg").hide() ;
$("#" + CBoxName + "_1_graphical").hide();
$("#"+ CBoxName +"_1_label").hide();


  };

  const audioVisualizer = new AudioVisualizer(audioContext, processFrame, processError);


  // Assign audioVisualizer instance to the global object to use it on the click function of the stop button
  window.audioVisualizer = audioVisualizer;
};

// DropBox Implementation starts from here
/*var refreshToken = "8QRVegvIqP4AAAAAAAAAAXM8id_GjRRQai9tLSALxxxH98aTuu6DY16nBOe1mVL0";
var base64authorization = btoa("0k4beryenn2qnob:9s01kw1dbz0xghn");
var accessToken;
var requestOptions = {
method: 'POST',
headers: {
  'Authorization': `Basic ${base64authorization}`,
  'Content-Type': 'application/x-www-form-urlencoded'
},
body: `refresh_token=${refreshToken}&grant_type=refresh_token`
};

fetch("https://api.dropbox.com/oauth2/token", requestOptions)
.then(response => response.json())
.then(data => {
  console.log('Response:', data);
  accessToken = data.access_token;
})
.catch(error => console.error('Error:', error));
*/